#include <asterkv/core/version.h>
#include <cstdlib>
#include <sstream>
#include <iostream>
#include <string_view>
#include <csignal>
#include <cstring>

#include "asterkv/network/tcp_server.h"
#include "asterkv/pipeline/local_pipeline.h"
#include "asterkv/storage/in_memory_storage.h"

namespace {
    volatile std::sig_atomic_t stopRequested = 0;

    void handleStopSignal(int /* signalNumber */) {
        stopRequested = 1;
    }

    [[nodiscard]] bool isStopRequested() noexcept {
        return stopRequested != 0;
    }

    [[nodiscard]] AsterKV::Core::Status installStopSignalHandlers() {
        struct sigaction action {};
        action.sa_handler = handleStopSignal;
        action.sa_flags = 0;

        if (::sigemptyset(&action.sa_mask) != 0) {
            std::string message = "failed to initialize signal mask: ";
            message.append(std::strerror(errno));

            return AsterKV::Core::Status::unavailable(message);
        }

        if (::sigaction(SIGINT, &action, nullptr) != 0) {
            std::string message = "failed to install SIGINT handler: ";
            message.append(std::strerror(errno));

            return AsterKV::Core::Status::unavailable(message);
        }

        if (::sigaction(SIGTERM, &action, nullptr) != 0) {
            std::string message = "failed to install SIGTERM handler: ";
            message.append(std::strerror(errno));

            return AsterKV::Core::Status::unavailable(message);
        }

        return AsterKV::Core::Status::ok();
    }

    void printUsage(std::string_view execName) {
        std::cout
            << "Usage: " << execName << " [--version] [--help]\n"
            << "       " << execName << " --local\n"
            << "       " << execName << " --local <command>\n"
            << "       " << execName << " --listen <host:port>\n\n"
            << "AsterKV server daemon.\n\n"
            << "Options:\n"
            << "    --version               Print version information.\n"
            << "    --help                  Print this help message.\n"
            << "    --local                 Run local stdin command mode without TCP networking\n"
            << "    --listen <host:port>    Run blocking TCP line server for one client\n\n"
            << "Examples:\n"
            << "  " << execName << " --local PING\n"
            << "  " << execName << " --local \"SET username alex\"\n"
            << "  printf 'PING'\\n | " << execName << " --local\n"
            << " " << execName << " --listen 127.0.0.1:" << AsterKV::Network::defaultClientPort << '\n'
        ;
    }

    [[nodiscard]] std::string joinArguments(int argc, char **argv, int startIndex) {
        std::ostringstream stream;

        for (int index = startIndex; index < argc; ++index) {
            if (index > startIndex) {
                stream << ' ';
            }

            stream << argv[index];
        }

        return stream.str();
    }

    void printProtocolResponse(std::string_view response) {
        std::cout << response;

        if (response.empty() || response.back() != '\n') {
            std::cout << '\n';
        }
    }

    int runLocalSingleCommand(int argc, char **argv) {
        AsterKV::Storage::InMemoryStorage storage;
        AsterKV::Pipeline::LocalPipeline pipeline {storage};

        const std::string cmdLine = joinArguments(argc, argv, 2);
        const std::string response = pipeline.processLine(cmdLine);

        printProtocolResponse(response);

        return EXIT_SUCCESS;
    }

    int runLocalStdinMode() {
        AsterKV::Storage::InMemoryStorage storage;
        AsterKV::Pipeline::LocalPipeline pipeline {storage};

        std::string line;

        while (std::getline(std::cin, line)) {
            if (line == "quit" || line == "exit") {
                return EXIT_SUCCESS;
            }

            if (line.empty()) {
                continue;
            }

            const std::string response = pipeline.processLine(line);
            printProtocolResponse(response);
        }

        return EXIT_SUCCESS;
    }

    int runLocalMode(int argc, char **argv) {
        if (argc == 2) {
            return runLocalStdinMode();
        }

        return runLocalSingleCommand(argc, argv);
    }

    int runListenMode(std::string_view endpointText) {
        auto endpoint = AsterKV::Network::parseTcpEndpoint(endpointText);

        if (endpoint.isError()) {
            std::cerr << "Invalid listen address: " << endpoint.status().message() << '\n';
            return EXIT_FAILURE;
        }

        AsterKV::Core::Status signalStatus = installStopSignalHandlers();
        if (!signalStatus.isOk()) {
            std::cerr << "Failed to initialize graceful shutdown: " << signalStatus.message() << '\n';

            return EXIT_FAILURE;
        }

        AsterKV::Storage::InMemoryStorage storage;
        AsterKV::Pipeline::LocalPipeline pipeline {storage};
        AsterKV::Network::TcpLineServer server {endpoint.value(), pipeline};

        std::cout << "AsterKV listening on "
                << AsterKV::Network::tcpEndpointToString(server.endpoint())
                << '\n'
                << "Press Ctrl+C to stop.\n";
        AsterKV::Core::Status status = server.run(isStopRequested);

        if (!status.isOk()) {
            std::cerr << "TCP server failed: " << status.codeString() << ' ' << status.message() << '\n';
            return EXIT_FAILURE;
        }

        std::cout << "AsterKV server stopped.\n";

        return EXIT_SUCCESS;
    }
}

int main(const int argc, char **argv) {
    const std::string_view execName = argc > 0 ? argv[0] : "asterd";

    if (argc == 1) {
        printUsage(execName);

        return EXIT_SUCCESS;
    }

    const std::string_view argument = argv[1];

    if (argument == "--version") {
        std::cout << AsterKV::Core::projectName() << " daemon " << AsterKV::Core::versionString() << '\n';

        return EXIT_SUCCESS;
    }

    if (argument == "--help") {
        printUsage(execName);

        return EXIT_SUCCESS;
    }

    if (argument == "--local") {
        return runLocalMode(argc, argv);
    }

    if (argument == "--listen") {
        if (argc != 3) {
            std::cerr << "--listen requires <host:port>\n";
            return EXIT_FAILURE;
        }

        return runListenMode(argv[2]);
    }

    std::cerr << "Unknown argument: " << argument << std::endl;
    printUsage(execName);

    return EXIT_FAILURE;
}
