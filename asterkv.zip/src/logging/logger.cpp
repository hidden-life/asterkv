#include <asterkv/logging/logger.h>

#include <spdlog/sinks/stdout_color_sinks.h>

#include <string>

namespace AsterKV::Logging {
    namespace {
        [[nodiscard]] bool equalsIgnoreCase(std::string_view left, std::string_view right) noexcept {
            if (left.size() != right.size()) {
                return false;
            }

            for (std::size_t index = 0; index < left.size(); ++index) {
                const char leftChar = left[index];
                const char rightChar = right[index];

                const char normalizedLeft = leftChar >= 'A' && leftChar <= 'Z' ? static_cast<char>(leftChar - 'A' + 'a') : leftChar;
                const char normalizedRight = rightChar >= 'A' && rightChar <= 'Z' ? static_cast<char>(rightChar - 'A' + 'a') : rightChar;

                if (normalizedLeft != normalizedRight) {
                    return false;
                }
            }

            return true;
        }
    }

    std::string_view logLevelToString(LogLevel level) noexcept {
        switch (level) {
            case LogLevel::Debug:
                return "debug";
            case LogLevel::Info:
                return "info";
            case LogLevel::Warn:
                return "warn";
            case LogLevel::Error:
                return "error";
            case LogLevel::Critical:
                return "critical";
            case LogLevel::Off:
                return "off";
        }

        return "unknown";
    }

    Core::Result<LogLevel> logLevelFromString(std::string_view value) {
        if (equalsIgnoreCase(value, "debug")) {
            return Core::Result<LogLevel>::success(LogLevel::Debug);
        }

        if (equalsIgnoreCase(value, "info")) {
            return Core::Result<LogLevel>::success(LogLevel::Info);
        }

        if (equalsIgnoreCase(value, "warn") || equalsIgnoreCase(value, "warning")) {
            return Core::Result<LogLevel>::success(LogLevel::Warn);
        }

        if (equalsIgnoreCase(value, "error")) {
            return Core::Result<LogLevel>::success(LogLevel::Error);
        }

        if (equalsIgnoreCase(value, "critical")) {
            return Core::Result<LogLevel>::success(LogLevel::Critical);
        }

        if (equalsIgnoreCase(value, "off")) {
            return Core::Result<LogLevel>::success(LogLevel::Off);
        }

        return Core::Result<LogLevel>::failure(
            Core::Status::invalidArgument("unknown log level")
        );
    }

    spdlog::level::level_enum toSpdlogLevel(LogLevel level) noexcept {
        switch (level) {
            case LogLevel::Debug:
                return spdlog::level::debug;
            case LogLevel::Info:
                return spdlog::level::info;
            case LogLevel::Warn:
                return spdlog::level::warn;
            case LogLevel::Error:
                return spdlog::level::err;
            case LogLevel::Critical:
                return spdlog::level::critical;
            case LogLevel::Off:
                return spdlog::level::off;
        }

        return spdlog::level::info;
    }

    LoggerPtr createConsoleLogger(std::string_view loggerName, LogLevel minLevel) {
        const std::string name {loggerName};
        LoggerPtr logger = spdlog::get(name);
        if (logger == nullptr) {
            logger = spdlog::stderr_color_mt(name);
        }

        logger->set_level(toSpdlogLevel(minLevel));
        logger->set_pattern("[%Y-%m-%d %H:%M:%S.%e] [%l] [%n] %v");
        logger->flush_on(spdlog::level::warn);

        return logger;
    }

    void setLoggerLevel(const LoggerPtr &logger, LogLevel level) {
        if (logger != nullptr) {
            logger->set_level(toSpdlogLevel(level));
        }
    }

    void log(const LoggerPtr &logger, LogLevel level, std::string_view message) {
        if (logger == nullptr) {
            return;
        }

        logger->log(toSpdlogLevel(level), SPDLOG_FMT_RUNTIME("{}"), message);
    }

    void debug(const LoggerPtr &logger, std::string_view message) {
    }

    void info(const LoggerPtr &logger, std::string_view message) {
    }

    void warn(const LoggerPtr &logger, std::string_view message) {
    }

    void error(const LoggerPtr &logger, std::string_view message) {
    }

    void critical(const LoggerPtr &logger, std::string_view message) {
    }
}
