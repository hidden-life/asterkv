#include <asterkv/server/tcp_server_runtime.h>
#include <asterkv/server/signal_shutdown_controller.h>

#include <utility>

namespace AsterKV::Server {
    TcpServerRuntime::TcpServerRuntime(TcpServerOptions options):
        options_(std::move(options)),
        storage_(),
        pipeline_(storage_),
        server_(options_.endpoint, pipeline_, Network::TcpLineServerOptions {
            .maxClientWorkers = options_.maxClientWorkers,
            .clientIdleTimeoutSeconds = options_.clientIdleTimeoutSeconds,
            .logger = options_.logger,
        }) {
    }

    const TcpServerOptions & TcpServerRuntime::options() const noexcept {
        return options_;
    }

    const Network::TcpEndpoint & TcpServerRuntime::endpoint() const noexcept {
        return server_.endpoint();
    }

    Core::Status TcpServerRuntime::run() {
        if (options_.logger != nullptr) {
            options_.logger->info("installing TCP server shutdown signal handlers");
        }

        Core::Status signalStatus = SignalShutdownController::install();
        if (!signalStatus.isOk()) {
            if (options_.logger != nullptr) {
                options_.logger->error("failed to install TCP server shutdown signal handlers");
            }

            return signalStatus;
        }

        if (options_.logger != nullptr) {
            options_.logger->info("starting TCP server runtime");
        }

        Core::Status status = server_.run(SignalShutdownController::stopRequested);
        if (!status.isOk()) {
            if (options_.logger != nullptr) {
                options_.logger->error("TCP server runtime stopped with error: {} {}", status.codeString(), status.message());
            }

            return status;
        }

        if (options_.logger != nullptr) {
            options_.logger->info("TCP server runtime stopped");
        }

        return Core::Status::ok();
    }
}
