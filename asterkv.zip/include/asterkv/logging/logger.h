#ifndef ASTERKV_LOGGING_LOGGER_H
#define ASTERKV_LOGGING_LOGGER_H

#include <asterkv/core/result.h>

#include <memory>
#include <string_view>

#include <spdlog/spdlog.h>

namespace AsterKV::Logging {
    enum class LogLevel {
        Debug,
        Info,
        Warn,
        Error,
        Critical,
        Off,
    };

    using Logger = spdlog::logger;
    using LoggerPtr = std::shared_ptr<Logger>;

    [[nodiscard]] std::string_view logLevelToString(LogLevel level) noexcept;
    [[nodiscard]] Core::Result<LogLevel> logLevelFromString(std::string_view value);

    [[nodiscard]] spdlog::level::level_enum toSpdlogLevel(LogLevel level) noexcept;

    [[nodiscard]] LoggerPtr createConsoleLogger(std::string_view loggerName, LogLevel minLevel = LogLevel::Info);

    void setLoggerLevel(const LoggerPtr &logger, LogLevel level);

    void log(const LoggerPtr &logger, LogLevel level, std::string_view message);
    void debug(const LoggerPtr &logger, std::string_view message);
    void info(const LoggerPtr &logger, std::string_view message);
    void warn(const LoggerPtr &logger, std::string_view message);
    void error(const LoggerPtr &logger, std::string_view message);
    void critical(const LoggerPtr &logger, std::string_view message);
}

#endif //ASTERKV_LOGGING_LOGGER_H
